#include "rrt_connect/rrt_connect.hpp"
#include <random>

namespace rrt_connect
{

void RRTConnect::configure(
    const rclcpp_lifecycle::LifecycleNode::WeakPtr & parent,
    std::string name,
    std::shared_ptr<tf2_ros::Buffer> tf,
    std::shared_ptr<nav2_costmap_2d::Costmap2DROS> costmap_ros){
        node_ = parent.lock();//현재 노드 객체가 소멸되지 않고, 살아있는지 확인한다.
        costmap_ros_ = costmap_ros;
   //     (void) name;
     //   (void) tf;
        RCLCPP_INFO( logger_ , "RRT Connect Algorithm is configured");
    }

    void RRTConnect::cleanup(){RCLCPP_INFO(logger_,"RRT Connect is cleanup.");}
    void RRTConnect::activate(){RCLCPP_INFO(logger_,"RRT Connect is activated");}
    void RRTConnect::deactivate(){RCLCPP_INFO(logger_ , "RRT Connect is deactivated");}

    bool RRTConnect::isCollisionFree(double x0 , double y0 , double x1 , double y1){
        unsigned int costmap_x , costmap_y;
        double distance = hypot( x1-x0 , y1-y0 );
        int steps = static_cast<int>(distance/0.05); // 0.5 = 50cm

        for ( int i=0 ; i<=steps ; i++){
            double x = x0 + (x1-x0)*i /steps;
            double y = y0 + (y1-y0)*i /steps;
            
            if (!costmap_ros_ -> getCostmap() -> worldToMap( x , y , costmap_x , costmap_y ) ){
            //    RCLCPP_WARN( logger_ , "지정한 좌표는 costmap의 바깥쪽 입니다. 지정한 좌표는 (%f , %f)" , x ,y );
                return false;
            }

            double cell_cost = costmap_ros_ -> getCostmap() -> getCost( costmap_x , costmap_y );
            if ( cell_cost >= 254 ){
              //  RCLCPP_WARN( logger_ , "costmap cost is over 254... collision!정한 좌표는 (%f , %f)" , x , y);
                return false;
            }
            else if(cell_cost >= 100){
                //RCLCPP_WARN(logger_ , "not explored area... it would be danger!정한 좌표는 (%f , %f)" , x , y);
                return false;
            }
        }
        return true;
    }


nav_msgs::msg::Path RRTConnect::createPlan(const geometry_msgs::msg::PoseStamped & start , const geometry_msgs::msg::PoseStamped & goal ){
    std::random_device rd;
    std::mt19937 gen(rd());
    nav_msgs::msg::Path path;
    path.header.frame_id = "map"; // global coordinate.

    struct Node{
        geometry_msgs::msg::PoseStamped pose;
        int parent;
        double cost;
        std::vector<int> children;
    };

    std::vector<Node> tree_start;
    std::vector<Node> tree_goal;
    bool extend_start = true;
    tree_start.push_back( { start , -1 , 0.0 , {} } );
    tree_goal.push_back( { goal , -1 , 0.0 , {} } );

    std::uniform_real_distribution<> rand_x(
        costmap_ros_ -> getCostmap() -> getOriginX() ,
        costmap_ros_ -> getCostmap() -> getOriginX() + costmap_ros_ -> getCostmap() -> getSizeInMetersX() );

    std::uniform_real_distribution<> rand_y(
        costmap_ros_ -> getCostmap() -> getOriginY() ,
        costmap_ros_ -> getCostmap() -> getOriginY() + costmap_ros_ -> getCostmap() -> getSizeInMetersY() );

    std::uniform_real_distribution<> rand_goal_sampling(0.0 , 1.0);

    // ==================RRT Connect parameter================
    const int MAX_ITERATIONS = 5000;
    const double STEP_SIZE = 0.5;  // 한번에 뻗어 나가는 거리. 0.5=50cm
    const double GOAL_THRESHOLD = 0.3; // 목표 지점에 도달했다고 보는 거리
    const double GOAL_BIAS = 0.1; // goal을 샘플링 할 확률... 10 %

    auto start_time = node_ -> now();
    RCLCPP_INFO( logger_ , "RRT Connect Algorithm Start...  max_iteration is %d " , MAX_ITERATIONS);

    // tree를 생성하기 위한 반복 루프.
    for( int i=0 ; i<MAX_ITERATIONS ; i++){
        if( (node_ -> now() - start_time).seconds() > 1.0 ){ // 1.0 = 1s  , 0.5 = 0.5seconds
            RCLCPP_WARN( logger_ , "RRT Connect Algorithm의 경로 생성 시간이 초과 되었습니다. 햔제 상장 시간은 1초 입니다.");
            break;
        }

        // 1. random sampling
        geometry_msgs::msg::PoseStamped q_rand;
        if ( rand_goal_sampling(gen) < GOAL_BIAS){
            q_rand = goal;
        }
        else{
            q_rand.pose.position.x = rand_x(gen);
            q_rand.pose.position.y = rand_y(gen);
        }

        // 2. q_rand에서 가장 가까운 노드인 q_near을 찾는다.
        int nearest_idx = -1;
        double min_dist = std::numeric_limits<double>::max();
        // 2-1. case-1... extend tree_start
        if( extend_start == true){
            for ( size_t j=0 ; j<tree_start.size() ; j++){
                double dx = q_rand.pose.position.x - tree_start[j].pose.pose.position.x;
                double dy = q_rand.pose.position.y - tree_start[j].pose.pose.position.y;
                double dist = sqrt( dx*dx + dy*dy );
                if ( dist < min_dist ){
                    min_dist = dist;
                    nearest_idx = j;
                }
            }
        }
        // 2-2. case-2... extend tree_goal
        else{
            for ( size_t j=0 ; j<tree_goal.size() ; j++){
                double dx = q_rand.pose.position.x - tree_goal[j].pose.pose.position.x;
                double dy = q_rand.pose.position.y - tree_goal[j].pose.pose.position.y;
                double dist = sqrt( dx*dx + dy*dy );
                if ( dist < min_dist ){
                    min_dist = dist;
                    nearest_idx = j;
                }
            }
        }


        // 3. q_rand로 q_nearest가 뻗어나아갈 방향을 계산한다.그리고 해당 방향으로 step_size만큼 이동한 좌표를 구한다
        double new_x , new_y;
        // 3-1. case-1... find angle tree_start
        if( extend_start == true){
            double angle = atan2( q_rand.pose.position.y - tree_start[nearest_idx].pose.pose.position.y,
                                q_rand.pose.position.x - tree_start[nearest_idx].pose.pose.position.x);
            new_x = tree_start[nearest_idx].pose.pose.position.x + STEP_SIZE * cos(angle);
            new_y = tree_start[nearest_idx].pose.pose.position.y + STEP_SIZE * sin(angle);
        }
        //3-2. case-2... find angle tree_goal
        else{
            double angle = atan2( q_rand.pose.position.y - tree_goal[nearest_idx].pose.pose.position.y,
                                q_rand.pose.position.x - tree_goal[nearest_idx].pose.pose.position.x);
            new_x = tree_goal[nearest_idx].pose.pose.position.x + STEP_SIZE * cos(angle);
            new_y = tree_goal[nearest_idx].pose.pose.position.y + STEP_SIZE * sin(angle);
        }        

        // 4. 생성할 q_new로 향하는 edge가 충돌하는지 체크
        //4-1.  case-1... collision-check tree_start

        if( extend_start == true){
            if ( !isCollisionFree( tree_start[nearest_idx].pose.pose.position.x , tree_start[nearest_idx].pose.pose.position.y , new_x , new_y ) ){
                continue;
            }
        }  
        //4-2.  case-2... collision-check tree_goal
        else{
            if ( !isCollisionFree( tree_goal[nearest_idx].pose.pose.position.x , tree_goal[nearest_idx].pose.pose.position.y , new_x , new_y ) ){
                continue;
            }
        }        
     //   RCLCPP_WARN( logger_ , "지정한 좌표 (%f , %f)" , new_x ,new_y );
        // 5. q_new를 생성한다. 그리고 트리에 추가한다.
        Node q_new;
        //5-1. q_new append to tree_start
        if( extend_start == true ){ 
            q_new.pose.pose.position.x = new_x;
            q_new.pose.pose.position.y = new_y;
            q_new.parent = nearest_idx;
            q_new.cost = tree_start[ q_new.parent ].cost + 
                        hypot( new_x - tree_start[q_new.parent].pose.pose.position.x , new_y - tree_start[q_new.parent].pose.pose.position.y );
            tree_start.push_back(q_new);
            int q_new_idx = static_cast<int>( tree_start.size() ) -1;
            tree_start[nearest_idx].children.push_back( q_new_idx );
        }
        // 5-2. q_new append to tree_goal
        else{
            q_new.pose.pose.position.x = new_x;
            q_new.pose.pose.position.y = new_y;
            q_new.parent = nearest_idx;
            q_new.cost = tree_goal[ q_new.parent ].cost + 
                        hypot( new_x - tree_goal[q_new.parent].pose.pose.position.x , new_y - tree_goal[q_new.parent].pose.pose.position.y );
            tree_goal.push_back(q_new);
            int q_new_idx = static_cast<int>( tree_goal.size() ) -1;
            tree_goal[nearest_idx].children.push_back( q_new_idx );
        }

        // 6. q_new가 q_goal까지 가까워졌는지 확인한다.
        // 6-1. tree_start is extend...  tree_goal is connect
        if ( extend_start == true ){
            // 6-1-1. 우선 q_new와 tree_goal의 노드들중에서 가장 가까운 노드를 찾아야한다.
            int nearest_node_in_tree_goal = -1;
            double min_dist_tree_goal = std::numeric_limits<double>::max();
            for ( size_t j=0 ; j<tree_goal.size() ; j++){
                double dx = q_new.pose.pose.position.x - tree_goal[j].pose.pose.position.x;
                double dy = q_new.pose.pose.position.y - tree_goal[j].pose.pose.position.y;
                double dist = sqrt( dx*dx + dy*dy );
                if ( dist < min_dist_tree_goal ){
                    min_dist_tree_goal = dist;
                    nearest_node_in_tree_goal = j;
                }
            }
            // double q_new_To_q_goal_dist = hypot( goal.pose.position.x - q_new.pose.pose.position.x , goal.pose.position.y - q_new.pose.pose.position.y );
            // 6-1-2. q_start에서 extend연산만으로 goal까지 충분히 가까워 진 경우 
            if ( min_dist_tree_goal < GOAL_THRESHOLD ){
                int q_new_idx = tree_start.size() -1;
                // tree_start를 뒤에서 부터 빼서, path에 앞쪽에 삽입하는 형식으로 경로 생성
                for ( int idx = q_new_idx ; idx != -1 ; idx = tree_start[idx].parent ){
                    path.poses.insert( path.poses.begin() , tree_start[idx].pose );
                }// tree_goal을 뒤에서부터 빼서, path의 앞쪽에 삽입 
                for ( int idx = nearest_node_in_tree_goal ; idx != -1 ; idx = tree_goal[idx].parent ){
                    path.poses.insert( path.poses.end() , tree_goal[idx].pose );
                }

                path.header.stamp = node_ -> now();
                path.header.frame_id = "map";
                for ( auto &pose : path.poses ){
                    pose.header.stamp = path.header.stamp;
                    pose.header.frame_id = path.header.frame_id;
                }
                auto end_time = node_ -> now() - start_time;
                RCLCPP_INFO( logger_ ,"=====>tree_start에서 extend후에 경로 생성." );
                RCLCPP_INFO( logger_ ,"=====>걸린시간 %.6f이며 최종적인 반복횟수는 %.1d" , end_time.seconds()  , i);
                RCLCPP_INFO(logger_, "Path size: %ld . 즉, 경로에 존재하는 노드 수 ", path.poses.size());
                RCLCPP_INFO( logger_ , "=====> 최종적인 경로 비용 %.6f 입니다. 트리에 존재하는 노드는 %.6ld개 이다." , tree_start.back().cost + tree_goal.back().cost + min_dist_tree_goal , tree_start.size() + tree_goal.size() );

                return path;
            }
            //6-1-3. tree_start에서 extend를 하고 나서도, goal에 도달하지 못했다면, tree_goal에서 connect를 수행한다.
            //6-1-3-1. tree_goal의 노드들중에서 q_new와 가장 가까운 노드를 찾는다.
            int nearest_idx_connect = -1;
            double min_dist_connect = std::numeric_limits<double>::max();
            for ( size_t j=0 ; j<tree_goal.size() ; j++){
                double dx = q_new.pose.pose.position.x - tree_goal[j].pose.pose.position.x;
                double dy = q_new.pose.pose.position.y - tree_goal[j].pose.pose.position.y;
                double dist = sqrt( dx*dx + dy*dy );
                if ( dist < min_dist_connect ){
                    min_dist_connect = dist;
                    nearest_idx_connect = j;
                }
            }
            //6-1-3-2. q_new방향으로 tree_goal의 방향을 구한다.
            double angle_connect = atan2( q_new.pose.pose.position.y - tree_goal[nearest_idx_connect].pose.pose.position.y,
                                q_new.pose.pose.position.x - tree_goal[nearest_idx_connect].pose.pose.position.x);

            bool flag = false;

            while(true){
                //6-1-3-3. q_new방향으로 이동한 좌표를 구한다.
                double new_x_connect = tree_goal[nearest_idx_connect].pose.pose.position.x + STEP_SIZE * cos(angle_connect);
                double new_y_connect = tree_goal[nearest_idx_connect].pose.pose.position.y + STEP_SIZE * sin(angle_connect);
                
                if ( !isCollisionFree( tree_goal[nearest_idx_connect].pose.pose.position.x , tree_goal[nearest_idx_connect].pose.pose.position.y , new_x_connect , new_y_connect ) ){
                    flag = true;
                    break;
                }
                // 6-1-3-3. q_new방향으로 connect를 시도하는 node를 생성한다. 그리고 tree_goal에 추가한다.
                Node q_new_connect;
                q_new_connect.pose.pose.position.x = new_x_connect;
                q_new_connect.pose.pose.position.y = new_y_connect;
                q_new_connect.parent = nearest_idx_connect;
                q_new_connect.cost = tree_goal[ q_new_connect.parent ].cost + 
                            hypot( new_x_connect - tree_goal[q_new_connect.parent].pose.pose.position.x , new_y_connect - tree_goal[q_new_connect.parent].pose.pose.position.y );
                tree_goal.push_back(q_new_connect);
                int q_new_idx_connect = static_cast<int>( tree_goal.size() ) -1;
                tree_goal[nearest_idx_connect].children.push_back( q_new_idx_connect );
                nearest_idx_connect = q_new_idx_connect; 
                // 6-1-3-4. connect를 시도한 node가 goal과 가까워졌는지 확인한다. 
                double min_dist_tree_goal_connect = hypot( q_new.pose.pose.position.x  - new_x_connect , q_new.pose.pose.position.y  - new_y_connect );
                if (  min_dist_tree_goal_connect < GOAL_THRESHOLD ){
                    // tree_start를 뒤에서 부터 빼서, path에 앞쪽에 삽입하는 형식으로 경로 생성
                    for ( int idx = tree_start.size() -1 ; idx != -1 ; idx = tree_start[idx].parent ){
                        path.poses.insert( path.poses.begin() , tree_start[idx].pose );
                    }// tree_goal을 뒤에서부터 빼서, path의 앞쪽에 삽입 
                    for ( int idx = nearest_idx_connect ; idx != -1 ; idx = tree_goal[idx].parent ){
                        path.poses.insert( path.poses.end() , tree_goal[idx].pose );
                    }

                    path.header.stamp = node_ -> now();
                    path.header.frame_id = "map";
                    for ( auto &pose : path.poses ){
                        pose.header.stamp = path.header.stamp;
                        pose.header.frame_id = path.header.frame_id;
                    }
                    auto end_time = node_ -> now() - start_time;
                    RCLCPP_INFO( logger_ ,"=====>tree_start에서 extend후, tree_goal에서 connect수행후 경로 생성." );
                    RCLCPP_INFO( logger_ ,"=====>걸린시간 %.6f이며 최종적인 반복횟수는 %.1d" , end_time.seconds()  , i);
                    RCLCPP_INFO(logger_, "Path size: %ld . 즉, 경로에 존재하는 노드 수 ", path.poses.size());
                    RCLCPP_INFO( logger_ , "=====> 수정할 로그... 최종적인 경로 비용 %.6f 입니다. 트리에 존재하는 노드는 %.6ld개 이다." , tree_start.back().cost + tree_goal.back().cost + min_dist_tree_goal_connect , tree_start.size() + tree_goal.size() );

                    return path;
                }
                // 6-1-3-5. 현재 생성한 노드가 충돌하지 않고, goal에도 충분히 도달 못했다... 그러면 다음 connect를 시도해야지.
            }
                if ( flag == true){
                    extend_start = false;
                    continue;
                }
            //6-1-4. connect연산이 끝났으니, 다시 한번 더 tree_start와 tree_goal이 이어질수 있는지 확인한다.

        }
        //6-2. tree_goal is extend...  tree_start is connect
        else{
            // 6-2-1. 우선 q_new와 tree_start의 노드들중에서 가장 가까운 노드를 찾아야한다.
            int nearest_node_in_tree_start = -1;
            double min_dist_tree_start = std::numeric_limits<double>::max();
            for ( size_t j=0 ; j<tree_start.size() ; j++){
                double dx = q_new.pose.pose.position.x - tree_start[j].pose.pose.position.x;
                double dy = q_new.pose.pose.position.y - tree_start[j].pose.pose.position.y;
                double dist = sqrt( dx*dx + dy*dy );
                if ( dist < min_dist_tree_start ){
                    min_dist_tree_start = dist;
                    nearest_node_in_tree_start = j;
                }
            }
            // double q_new_To_q_goal_dist = hypot( goal.pose.position.x - q_new.pose.pose.position.x , goal.pose.position.y - q_new.pose.pose.position.y );
            // 6-2-2. q_goal에서 extend연산만으로 goal까지 충분히 가까워 진 경우 
            if ( min_dist_tree_start < GOAL_THRESHOLD ){
                int q_new_idx = tree_start.size() -1;
                // tree_start를 뒤에서 부터 빼서, path에 앞쪽에 삽입하는 형식으로 경로 생성
                for ( int idx = q_new_idx ; idx != -1 ; idx = tree_start[idx].parent ){
                    path.poses.insert( path.poses.begin() , tree_start[idx].pose );
                }// tree_goal을 뒤에서부터 빼서, path의 앞쪽에 삽입 
                for ( int idx = tree_goal.size()-1 ; idx != -1 ; idx = tree_goal[idx].parent ){
                    path.poses.insert( path.poses.end() , tree_goal[idx].pose );
                }

                path.header.stamp = node_ -> now();
                path.header.frame_id = "map";
                for ( auto &pose : path.poses ){
                    pose.header.stamp = path.header.stamp;
                    pose.header.frame_id = path.header.frame_id;
                }
                auto end_time = node_ -> now() - start_time;
                RCLCPP_INFO( logger_ ,"=====>tree_goal에서 extend 수행후에 경로가 생성되었습니다.");
                RCLCPP_INFO( logger_ ,"=====>걸린시간 %.6f이며 최종적인 반복횟수는 %.1d" , end_time.seconds()  , i);
                RCLCPP_INFO(logger_, "Path size: %ld . 즉, 경로에 존재하는 노드 수 ", path.poses.size());
                RCLCPP_INFO( logger_ , "=====> 최종적인 경로 비용 %.6f 입니다. 트리에 존재하는 노드는 %.6ld개 이다." , tree_start.back().cost + tree_goal.back().cost + min_dist_tree_start , tree_start.size() + tree_goal.size() );

                return path;
            }
            //6-2-3. tree_goal에서 extend를 하고 나서도, goal에 도달하지 못했다면, tree_start에서 connect를 수행한다.
            //6-1-3-1. tree_start의 노드들중에서 q_goal와 가장 가까운 노드를 찾는다.
            int nearest_idx_connect = -1;
            double min_dist_connect = std::numeric_limits<double>::max();
            for ( size_t j=0 ; j<tree_start.size() ; j++){
                double dx = q_new.pose.pose.position.x - tree_start[j].pose.pose.position.x;
                double dy = q_new.pose.pose.position.y - tree_start[j].pose.pose.position.y;
                double dist = sqrt( dx*dx + dy*dy );
                if ( dist < min_dist_connect ){
                    min_dist_connect = dist;
                    nearest_idx_connect = j;
                }
            }
            //6-1-3-2. q_new방향으로 tree_start의 방향을 구한다.
            double angle_connect = atan2( q_new.pose.pose.position.y - tree_start[nearest_idx_connect].pose.pose.position.y,
                                q_new.pose.pose.position.x - tree_start[nearest_idx_connect].pose.pose.position.x);

            bool flag = false;

            while(true){
                //6-1-3-3. q_new방향으로 이동한 좌표를 구한다.
                double new_x_connect = tree_start[nearest_idx_connect].pose.pose.position.x + STEP_SIZE * cos(angle_connect);
                double new_y_connect = tree_start[nearest_idx_connect].pose.pose.position.y + STEP_SIZE * sin(angle_connect);
                
                if ( !isCollisionFree( tree_start[nearest_idx_connect].pose.pose.position.x , tree_start[nearest_idx_connect].pose.pose.position.y , new_x_connect , new_y_connect ) ){
                    flag = true;
                    break;
                }
                // 6-1-3-3. q_new방향으로 connect를 시도하는 node를 생성한다. 그리고 tree_start에 추가한다.
                Node q_new_connect;
                q_new_connect.pose.pose.position.x = new_x_connect;
                q_new_connect.pose.pose.position.y = new_y_connect;
                q_new_connect.parent = nearest_idx_connect;
                q_new_connect.cost = tree_start[ q_new_connect.parent ].cost + 
                            hypot( new_x_connect - tree_start[q_new_connect.parent].pose.pose.position.x , new_y_connect - tree_start[q_new_connect.parent].pose.pose.position.y );
                tree_start.push_back(q_new_connect);
                int q_new_idx_connect = static_cast<int>( tree_start.size() ) -1;
                tree_start[nearest_idx_connect].children.push_back( q_new_idx_connect );
                nearest_idx_connect = q_new_idx_connect;

                // 6-1-3-4. connect를 시도한 node가 tree_goal과 가까워졌는지 확인한다. 
                double min_dist_tree_start_connect = hypot( q_new.pose.pose.position.x  - new_x_connect , q_new.pose.pose.position.y  - new_y_connect );
                if (  min_dist_tree_start_connect < GOAL_THRESHOLD ){
                    // tree_start를 뒤에서 부터 빼서, path에 앞쪽에 삽입하는 형식으로 경로 생성
                    for ( int idx = tree_start.size() -1 ; idx != -1 ; idx = tree_start[idx].parent ){
                        path.poses.insert( path.poses.begin() , tree_start[idx].pose );
                    }// tree_goal을 뒤에서부터 빼서, path의 앞쪽에 삽입 
                    for ( int idx = tree_goal.size()-1 ; idx != -1 ; idx = tree_goal[idx].parent ){
                        path.poses.insert( path.poses.end() , tree_goal[idx].pose );
                    }

                    path.header.stamp = node_ -> now();
                    path.header.frame_id = "map";
                    for ( auto &pose : path.poses ){
                        pose.header.stamp = path.header.stamp;
                        pose.header.frame_id = path.header.frame_id;
                    }
                    auto end_time = node_ -> now() - start_time;
                    RCLCPP_INFO( logger_ ,"=====>tree_goal에서 extend후에 tree_start에서 connect연산후에 경로가 생성됨...");
                    RCLCPP_INFO( logger_ ,"=====>걸린시간 %.6f이며 최종적인 반복횟수는 %.1d" , end_time.seconds()  , i);
                    RCLCPP_INFO(logger_, "Path size: %ld . 즉, 경로에 존재하는 노드 수 ", path.poses.size());
                    RCLCPP_INFO( logger_ , "=====> 수정할 로그... 최종적인 경로 비용 %.6f 입니다. 트리에 존재하는 노드는 %.6ld개 이다." , tree_start.back().cost + tree_goal.back().cost + min_dist_tree_start_connect , tree_start.size() + tree_goal.size() );

                    return path;
                }
                // 6-1-3-5. 현재 생성한 노드가 충돌하지 않고, goal에도 충분히 도달 못했다... 그러면 다음 connect를 시도해야지.
            }

            if ( flag == true){
                extend_start = true;
                continue;
            }

            //6-1-4. connect연산이 끝났으니, 다시 한번 더 tree_start와 tree_goal이 이어질수 있는지 확인한다.

        }        


    }
    RCLCPP_WARN(logger_ , "**************** Failed to find path !!! ******************");
    return path;
}


}// namespace rrt_connect
#include <pluginlib/class_list_macros.hpp>

PLUGINLIB_EXPORT_CLASS(rrt_connect::RRTConnect, nav2_core::GlobalPlanner)